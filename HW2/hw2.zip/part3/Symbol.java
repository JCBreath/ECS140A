public class Symbol {
	public String id;
	public int lineNumber;

	public Symbol(String id, int lineNumber) {
		this.id = id;
		this.lineNumber = lineNumber;
	}
}